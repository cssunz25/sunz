﻿Поддержка только прошивка с уязвимостью create_log_backup.cgi

1. Вам нужно отредактировать settings.cfg
	-Установите параметр IPNETWORK сети. Если у вас есть 192.168.88. * - установите IPNETWORK=192.168.88 (192.168.1. *, установите IPNETWORK=192.168.1)
	-Установить диапазон сканирования IPSTART и IPEND. Если вы хотите сканировать с 192.168.1.2 по 192.168.1.40 - установите IPSTART=2, IPEND=40.
	-Установите веб-пароль Antminer ASICWEBPASS=ваш_пароль (По умолчанию: root)
	-Установить пароль ssh Antminer ASICSSHPASS=ваш_пароль (По умолчанию: admin)
2. Сканировать и разблокировать(если возможно) найденные устройства с помощью скрипта "1.unlock_ssh.bat".
3. Подождите 2-5 минут для загрузки Antminers.
4. Замените Upgrade.cgi скриптом "2.replace.bat".
5. Прошить любую прошивку с помощью BTCTools и т.д ..



Please note,  this SSH Unlocker only works on firmwares with the create_log_backup.cgi Vulnerability!!!!!!!

1. You need edit settings.cfg
	-Set network IPNETWORK parameter. If you have 192.168.88.* - set IPNETWORK=192.168.88 (192.168.1.*, set IPNETWORK=192.168.1)
	-Set scan range IPSTART and IPEND. If you want scan from 192.168.1.2 to 192.168.1.40 - set IPSTART=2 IPEND=40.
	-Set Antminer web password ASICWEBPASS=your_password. (Default: root)
	-Set Antminer ssh password ASICSSHPASS=your_password. (Default: admin)
2. Scan network and unlock(if possible) selected range with "1.unlock_ssh.bat" script.
3. Wait 2-5 min for Antminers boot up.
4. Replcase Upgrade.cgi with "2.replace.bat" script.
5. Flash any firmware with BTCTools, etc..


1.First, you need to edit the file called settings.cfg. You need to edit the following parameters: 
• Set your network with the IPNETWORK parameter.  
• Example; if your devices are on subnet 192.168.88.* 
• set IPNETWORK=192.168.88 
• Example; if your devices are on subnet 192.168.1.* 
▪ set IPNETWORK=192.168.1 
• Set the range for the script to scan with IPSTART and IPEND parameters.  
• Example; if you want the scan to include the range 192.168.1.2 to 192.168.1.40 
• set IPSTART=2 IPEND=40 
• Set the Antminer web password with the ASICWEBPASS parameter. The default password is root.  
• Example; ASICWEBPASS=root  
• Set the Antminer SSH password with the ASICSSHPASS parameter. The default password is admin.  
• Example; ASICWEBPASS=admin 

2.Executing the Unlock Script 
•Use the 1.unlock_ssh.bat script to unlock the SSH functionality on ant miners with vulnerable FW versions.  
•From the commandprompt, navigate to the folder where 1.unlock_ssh.bat is located, and execute  using the command 1.unlock_ssh.bat  
•Wait until the Antminer(s) have booted up again.  

3.Replacing replace.cgi  
• Use the 2.replace.bat script to replace the replace.cgi file with an updated version. This is needed in order to bypass file signature checks for new 3rd party FW uploads 
• From the commandprompt, navigate to the folder where 2.replace.bat is located, and execute using the command 2.replace.bat 

4. After the script is finished, you can upload the new Firmware using the webgui.